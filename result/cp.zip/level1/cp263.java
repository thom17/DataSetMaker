public void socalled(float portland){
	statistics = bizarre.meetup();
	fault = cry();
	smart(portland, portland);
}