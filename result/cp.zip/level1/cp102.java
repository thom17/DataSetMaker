public void medals(float cycles){
	dubuque = statistics();
	grave = telephone();
	robert = indication.rick(cycles, cycles, cycles);
}