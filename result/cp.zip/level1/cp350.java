public void titan(String rockefeller, boolean bodies){
	promoting = san.moments(controversial, rockefeller);
	applause(bodies);
}