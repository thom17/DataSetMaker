public void means(boolean registered){
	bushkerry = markets();
	destroy.acts(registered);
}