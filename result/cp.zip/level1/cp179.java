public void harry(float directors){
	proof = theories.angered();
	hollow = evaluations();
	compare = lebanon(directors);
}