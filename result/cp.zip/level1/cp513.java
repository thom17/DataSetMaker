public void achieve(String promote){
	blames = cohen.collectively(promote, promote, promote);
}