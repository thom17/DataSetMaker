public void quoted(float agenda){
	accounting.polls();
	join = hated(agenda, agenda);
}