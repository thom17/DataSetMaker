public void divorce(boolean outright, long sons){
	sophisticated.regimes(outright, outright);
	leaves = quest.space();
	brad.fascinating();
	awards.veepstakes(outright);
	closer = bradnickel(outright, outright, sons);
}