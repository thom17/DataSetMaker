public void plans(long politician){
	fielding.stagflation();
	mustve.falls();
	fulltime.scenarios();
	birth(politician, sway);
}