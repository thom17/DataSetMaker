public void price(String bill, long tossed){
	published = reading.admitted(tossed, tossed, tossed);
	ranking = soul();
	ddel();
	perpetrated = stupid.sort(bill);
}