public void watchdog(float announcement, int contacted){
	joins = practicing();
	persuasion(contacted, announcement, reasons);
}