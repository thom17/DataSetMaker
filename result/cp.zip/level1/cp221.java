public void hunting(double hersh){
	carl = clerks.heart(hersh, hersh, hersh);
}