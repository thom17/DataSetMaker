public void organizational(long turnout){
	rightly = deploy.housing();
	thoughtful(turnout, turnout, turnout);
}