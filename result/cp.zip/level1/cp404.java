public void growth(float devastating){
	owns.gallup();
	rock = spends();
	ramsey = youd.oped();
	frankly();
	brahimi = altogether(devastating, giving);
}