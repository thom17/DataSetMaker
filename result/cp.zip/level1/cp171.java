public void ward(String reid){
	crossing = minority(reid, reid, reid);
}