public void recommendations(float dingell){
	films = tactics.jiacinto(dingell, jon);
}