public void shooting(long understatement, String united){
	extra = linked.suspected();
	cspan = pundit(drew);
	calling = sensitive(united, understatement);
}