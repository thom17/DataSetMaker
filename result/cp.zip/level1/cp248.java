public void personally(double retreat){
	protection();
	text.rebellion();
	alsadr = metaphor(retreat, retreat, foundations);
}