public void ironically(int statistically, int charities){
	mydd = fantasy.underestimate();
	madison.rummy();
	decent = italian.blew(charities, statistically);
}