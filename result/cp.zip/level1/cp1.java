public void simultaneously(boolean supreme){
	kentucky = marginal.carl();
	complex = reuters.postsaddam(supreme, humphrey, supreme);
}