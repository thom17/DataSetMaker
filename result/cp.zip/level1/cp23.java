public void extension(String pelosi){
	vision = statute(explosives, pelosi);
}