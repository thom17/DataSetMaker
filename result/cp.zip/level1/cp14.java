public void coin(long shock, int fiscal){
	killing(fiscal);
	spiral = sales.hurt(fiscal);
	dump = construction();
	crap = accomplishment();
	club = valuable(fiscal, shock, fiscal);
}