public void main(float goldwater, int east){
	trix(east, cspan, goldwater);
}