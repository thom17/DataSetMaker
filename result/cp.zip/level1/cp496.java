public void soil(double signatures, int snapshot){
	shocked.ship();
	imperial = zahn();
	guide();
	feingold = feels();
	releases();
	nope = approximately.miss();
	insurgent = buying.challenged(slew);
	mercenaries(signatures, snapshot, snapshot);
}