public void select(double assignment){
	dominant = nagourney(assignment);
}