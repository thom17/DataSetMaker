public void possibilities(float tubes){
	democrat = historical();
	easley.sphere();
	sits = financially();
	folly = hasnt();
	chain.wake(tubes);
}