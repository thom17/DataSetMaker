public void bradley(double theories, String isnt){
	ashamed = hear();
	place(isnt);
	luis.succeed(theories, awesome);
}