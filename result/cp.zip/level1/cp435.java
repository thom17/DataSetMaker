public void snapshot(boolean democrat){
	street = allegory.analysis();
	insisting.cooperation(democrat);
}