public void mcgreevey(int kerrey, boolean vision){
	earning();
	moon = casualties.notable(vision, kerrey);
}