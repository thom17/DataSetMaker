public void data(boolean weekends){
	cosen = labor.abu();
	gulf = fodder(weekends);
}