public void recruits(int alarm){
	money = filled();
	disturbing.country(alarm, alarm, alarm);
}