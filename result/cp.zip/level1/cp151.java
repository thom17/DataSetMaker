public void victims(double gift){
	alzheimers(gift);
}