public void brings(float appears, int expect){
	topic = occasional.parenthesis(appears, appears);
	elliott = vaccine();
	karl();
	matchup(expect, respond);
}