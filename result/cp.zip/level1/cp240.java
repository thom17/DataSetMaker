public void balance(double shifts){
	drake();
	pause.tall();
	buh();
	rates.todd();
	atomic.bubble();
	weird = equally.wink(shifts);
}