public void furiousxgeorge(String dictator){
	investigative = dccc();
	endorsing = iii();
	static(dictator, dictator);
}