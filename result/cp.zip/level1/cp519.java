public void mcentee(long substantive){
	closing = extremists();
	altogether.sell();
	tonight();
	persuade = injured.declaration(substantive, substantive);
}