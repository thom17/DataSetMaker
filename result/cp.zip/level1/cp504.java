public void lawnorder(double states, int individuals){
	analysis = development.interactive();
	facing = soldier();
	undecideds();
	switch();
	enjoys(individuals, states);
}