public void veterans(double involved, boolean rumsfeld){
	turner = challenges();
	bounce();
	probush.prewar();
	output = theyll(involved);
	rep.block(rumsfeld);
}