public void roger(long permission){
	brahimi(permission, permission);
}