public void audio(boolean authorize){
	coattails = examples.sunshine(authorize);
}