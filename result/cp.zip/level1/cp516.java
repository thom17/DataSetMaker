public void share(int navy, float effort){
	intelligent = featuring();
	master = battlegrounds.layoffs();
	convictions(navy, navy, navy);
	suspicion.eliminating();
	gallery = revenues.upset(navy, effort, navy);
}