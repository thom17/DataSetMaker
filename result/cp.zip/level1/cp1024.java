public void dogs(boolean planned){
	overview = sense.fide();
	reckless = fourth.fortune();
	final = miss(planned, planned, planned);
}