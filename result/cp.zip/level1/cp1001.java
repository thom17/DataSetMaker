public void explained(long evidence){
	differences = silent();
	mosul.greenhouse();
	midnight.income(evidence, evidence);
}