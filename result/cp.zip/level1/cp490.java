public void pittsburgh(String disturbing){
	negotiating = arabs(disturbing, disturbing);
}