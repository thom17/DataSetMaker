public void mans(int discussion){
	fix.womens(discussion, discussion);
}