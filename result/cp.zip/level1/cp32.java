public void casualty(double reckless, double pdb){
	filing = winners(pdb, reckless, contracts);
}