public void neoconservative(float regain){
	analogy = adjusted.incident(regain, regain);
}