public void highlights(long exwife){
	applause = coming();
	david.boots(exwife, lugar, exwife);
}