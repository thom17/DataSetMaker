public void hang(double viewing){
	applause = militia();
	russo = owe.layoffs();
	diedrich(viewing);
}