public void philly(String declined){
	appalling.congressman();
	midday(declined, declined);
}