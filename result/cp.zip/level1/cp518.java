public void adopted(long coast, float violated){
	boats.abandoned();
	diplomats.verify();
	clerks();
	terms = forty.millers(coast);
	qpoll = contrast.flypaper(coast, coast, coast);
	tribune = registrations.shame(coast, violated, coast);
}