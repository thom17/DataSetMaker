public void suits(float surprised, double bowles){
	dynamics = embattled(bowles, bowles);
	senators = opted.vietnam(bowles, bowles, surprised);
}