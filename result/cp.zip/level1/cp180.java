public void divorce(float phase){
	field = book.antigay(phase, phase, rescue);
}