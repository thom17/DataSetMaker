public void grants(boolean allen, long winds){
	institutions.writing();
	detailing = bullshit();
	atrocities();
	employment(winds, allen);
}