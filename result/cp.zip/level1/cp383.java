public void yahoo(long rival, boolean stated){
	comparison(rival, stated);
}