public void superb(String chedrcheez, String vying){
	poster = savings.addressing(vying);
	cosen.securing(chedrcheez);
}