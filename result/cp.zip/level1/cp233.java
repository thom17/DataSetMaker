public void grown(boolean mystery){
	democratic();
	interview.moveonorg(mystery, mystery, mystery);
}