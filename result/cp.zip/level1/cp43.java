public void useless(long guerrillas){
	continuing = attempt.hospital();
	conducting = sway(guerrillas, guerrillas);
}