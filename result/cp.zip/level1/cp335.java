public void millionaire(float ban){
	condition = blamed(ban, ban, ban);
}