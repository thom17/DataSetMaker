public void gig(String expected){
	brahimi.return();
	moveonorg = moon.visits();
	ship = tensions.dynamic();
	represented();
	intentions();
	loved();
	ultimate(expected, claire);
}