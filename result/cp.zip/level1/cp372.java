public void advocate(double targetted){
	hearing.priorities();
	pole.wedge();
	detention(targetted, targetted, targetted);
}