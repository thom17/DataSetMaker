public void suspicion(String pickups){
	taught = wouldve();
	footage = brock(pickups, oped, pickups);
}