public void rarely(double foul){
	boundaries = chocola();
	rapids(foul, foul, foul);
}