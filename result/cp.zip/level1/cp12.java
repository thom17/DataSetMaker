public void blown(boolean cell){
	mask();
	melissa = mitch();
	bio = called();
	wire();
	events();
	explains();
	maintained = scsen(cell, cell);
}