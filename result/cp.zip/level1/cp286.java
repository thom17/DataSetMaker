public void commit(String solutions){
	campbell.cutting();
	composite = elliott.younger(carol, manufacturers, solutions);
}