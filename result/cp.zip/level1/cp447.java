public void spains(String alive){
	huge = occured(alive, alive);
}