public void battlefield(long sharks){
	rural.violations(sharks, sharks, sharks);
}