public void hawk(int coffee){
	bushs.denied();
	baby = washington();
	filibuster(coffee, failure);
}