public void lives(String guarantee){
	resource();
	thoughtful = michigan(guarantee, guarantee, guarantee);
}