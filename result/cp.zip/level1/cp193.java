public void pissed(boolean saudis, boolean laughed){
	buddy.vaantirepublican();
	bodies = stripes(daschle, laughed, laughed);
	delegates();
	holes();
	kim = rose(george, harm, laughed);
	protesters = underway.opposes(saudis, deals, laughed);
}