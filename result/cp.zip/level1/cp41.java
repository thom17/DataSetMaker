public void functioning(int compassionate, String los){
	bishops.generated();
	mulling = background.armed();
	mouse();
	sam(compassionate, los);
}