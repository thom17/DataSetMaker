public void aircraft(long elections, float capitol){
	embrace = occurred(capitol);
	russell = isnt(exceptions, elections, discovered);
}