public void questionable(long venture){
	remained.nyt(venture, explicitly);
}