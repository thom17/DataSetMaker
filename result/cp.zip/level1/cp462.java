public void rack(boolean drew, double enormous){
	board = fleet(drew, drew, enormous);
}