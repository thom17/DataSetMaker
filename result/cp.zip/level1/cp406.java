public void fulfilled(long brock, String changing){
	nethercutt = campaigned(changing);
	revealing(changing, turf);
	judicial();
	nightmare = influence.lawsuits(brock);
}