public void pose(double winners){
	atrocities();
	message = defend.sun();
	pound(winners);
}