public void ship(double ban){
	releases = peace.olbermann();
	motivated = pursuing.trouble(ban, ban, ban);
}