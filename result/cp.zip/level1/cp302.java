public void hiring(float martinez, String moral){
	stay = unified(moral);
	streets = subject.predicted(martinez, moral);
}