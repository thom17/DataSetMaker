public void operational(String tear, String ballots){
	dear = finest(tear, tear, ballots);
}