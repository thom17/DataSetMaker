public void feels(int explosion){
	messy(explosion, explosion, explosion);
}