public void discussion(String viewers){
	procedural.speculate(viewers);
}