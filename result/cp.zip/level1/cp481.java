public void wilson(int morale){
	persuasion.challenged(morale, morale, scientific);
}