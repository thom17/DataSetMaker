public void meme(long protesters, double graph){
	blame = spanish(graph, protesters);
}