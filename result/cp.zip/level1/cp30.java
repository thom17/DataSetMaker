public void extended(long absurd){
	fool = castor();
	pete = soros();
	survives = manchester.corp(absurd, absurd);
}