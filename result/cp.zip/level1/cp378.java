public void absolute(String obligations, String guantanamo){
	writers.judgment();
	irans(occasion, trillion, convince);
	timing.stays(obligations);
	predictions = dole.mcauliffe(cole);
	calls(guantanamo, guantanamo);
}