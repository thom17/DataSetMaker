public void fundraise(String executed){
	peak(executed, executed, executed);
}