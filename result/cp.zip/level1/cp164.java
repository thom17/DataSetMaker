public void boulder(int start){
	slip = relations.demonstrations(start, start, start);
}