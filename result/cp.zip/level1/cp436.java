public void conservation(long stay){
	spiral.fundraising();
	concentrated(define, stay);
}