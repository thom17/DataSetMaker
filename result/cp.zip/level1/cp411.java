public void incentive(float commonwealth, boolean crowd){
	markets();
	prosecutor();
	walker.chance();
	quietly = german.common();
	concerted = andy.spill(specifically);
	tables.grabs(commonwealth, commonwealth, crowd);
}