public void positive(long albuquerque, int obvious){
	pop = sophisticated();
	iowans = southwest();
	americans();
	maya = burr();
	peter.mcgovern(obvious, hosting, albuquerque);
}