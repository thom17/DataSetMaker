public void greenwood(boolean happy){
	powerful.aircraft(happy, happy);
}