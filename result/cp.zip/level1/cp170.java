public void abstain(boolean extent, boolean blogging){
	ten = navy();
	nighthorse();
	financially(extent);
	irresponsible = losses.est(extent);
	inactive = magazines();
	structure();
	teeth = edward.reverse();
	rockefeller(blogging);
}