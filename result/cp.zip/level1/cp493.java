public void pocket(float pushes){
	bushrove = parish.omb(pushes);
}