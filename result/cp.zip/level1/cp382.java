public void centers(boolean opted){
	inclined();
	agreement(opted);
}