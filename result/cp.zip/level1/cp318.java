public void emissions(float enforce){
	distract.pro(enforce);
}