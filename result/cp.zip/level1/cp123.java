public void cato(float individuals){
	recruiting();
	briefing(individuals);
}