public void speaker(float itd){
	russell = showed.lady(farmer, itd, itd);
}