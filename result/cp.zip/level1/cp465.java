public void stewart(String strongholds){
	ethic = allegedly(strongholds);
}