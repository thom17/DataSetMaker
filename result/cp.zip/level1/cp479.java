public void useless(int slipped){
	bluff = lame.tommy();
	slight = demands.harold();
	american = bunning(slipped, slipped, slipped);
}