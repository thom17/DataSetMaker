public void specters(boolean sharpton){
	dennis.performance();
	registration = boats.unecessary(sharpton, sharpton);
}