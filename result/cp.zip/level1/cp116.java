public void promote(String assist, float practices){
	printed = eye();
	battles.glance();
	fundamentals.redistricting(practices, assist);
}