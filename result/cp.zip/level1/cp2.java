public void compete(int noise){
	party = questioned(noise);
}