public void deliver(int mahdi, String liability){
	digging = vilsack();
	coverup = tuesdays.india();
	constant = weather.boston();
	signed = average(biological);
	principal(liability, hotel, mahdi);
}