public void pump(int wrap, String convenient){
	targeting = river();
	sharpton();
	saving();
	contested(wrap, convenient, convenient);
}