public void reviews(boolean fewer){
	mom = calistan.hecht();
	conversation.seattle(blocks, fewer);
}