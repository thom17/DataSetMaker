public void guilty(boolean replaced){
	vice(replaced, replaced, comfortable);
}