public void marked(String lean, String freakin){
	treatment = garner.illusions();
	spends.cell();
	syria.breakfast();
	granholm.stay();
	graphic(lean, lean, freakin);
}