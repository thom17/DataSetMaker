public void cleric(float looked, int means){
	release = owner(means, means, means);
	commissioner.charged();
	cpa = kingdom();
	crap = hardcore();
	luis(looked);
}