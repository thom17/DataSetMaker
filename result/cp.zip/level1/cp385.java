public void admire(int meaning){
	hoped = rest();
	institute.afraid();
	chalabi.shore(meaning);
}