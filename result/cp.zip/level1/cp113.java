public void alert(String tackle, String testy){
	crashed = demanded();
	broader = similar(testy, tackle, tackle);
}