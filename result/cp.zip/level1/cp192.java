public void reasonable(String interpretation){
	allawi(interpretation, interpretation, interpretation);
}