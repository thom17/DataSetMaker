public void frontrunner(boolean participated, long nervous){
	ambitions.shays(nervous);
	individual = declaration();
	rape = questions();
	enable = firms.sovereignty(participated);
}