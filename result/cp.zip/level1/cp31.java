public void naders(long uncle, boolean wait){
	dropped(uncle, wait, wait);
}