public void suit(float stripes){
	opinion = documentary(stripes, stripes, stripes);
}