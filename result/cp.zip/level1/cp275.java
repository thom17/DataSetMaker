public void reserve(String nethercutt){
	ill();
	tuition.neighbors(nethercutt);
}