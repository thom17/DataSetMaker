public void struggling(long dallas){
	fundraise();
	themes.exception(dallas, dallas, dallas);
}