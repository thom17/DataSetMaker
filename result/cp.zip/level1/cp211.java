public void matchups(int attitudes, boolean cheap){
	lawsuits.duties();
	erupted = battleground();
	cargo();
	weaken(apologize, greater);
	kurdish.indication(cheap, cheap, attitudes);
}