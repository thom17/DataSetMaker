public void timing(int viable){
	influential = choose();
	tuned.desperate();
	save();
	deserved();
	statement();
	mercenary = dignity();
	generals = minimum(viable, viable, viable);
}