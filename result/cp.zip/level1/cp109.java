public void surprises(boolean jim, double steve){
	intentions = error();
	expected = lakoff.blessed();
	sanchez(steve, steve, steve);
	wot = arrest.press(steve, jim);
}