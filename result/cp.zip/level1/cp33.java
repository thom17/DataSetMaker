public void yucca(long samples, int continued){
	convinced = partisan.lesbians(continued, samples, defined);
}