public void blogpac(boolean regions){
	diplomats = faithful();
	cross = incumbency.war(regions, regions, cho);
}