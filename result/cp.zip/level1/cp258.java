public void flopper(double read){
	stan.observers(rid);
	dem = beltway.responders();
	root = sponsored(read, read, read);
}