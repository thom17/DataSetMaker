public void band(String douglas){
	robinson = ladies.remarkably();
	knowing(douglas, douglas);
}