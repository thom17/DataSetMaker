public void movements(boolean specifics){
	suburbs.funeral();
	quickly = sunshine.bell(specifics, specifics);
}