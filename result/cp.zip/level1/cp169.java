public void trot(int paint){
	shaping.lacked();
	rocky();
	italy(stays, assumptions, paint);
}