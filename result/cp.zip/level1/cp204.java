public void btw(boolean rep){
	walk.saved(board);
	trillion = internal(rep, rep);
}