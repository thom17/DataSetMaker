public void disastrous(String dude){
	blades();
	tough = devine.tremendous();
	nominee.chocola(dude);
}