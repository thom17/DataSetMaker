public void gooper(long alive, float kingelection){
	suffered.joining();
	annenberg();
	talked.opportunity(kingelection, alive, kingelection);
}