public void mess(double priorities){
	clarks = hed();
	dropping();
	consumer.confusion(truck, priorities);
}