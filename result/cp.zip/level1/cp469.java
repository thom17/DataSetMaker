public void shock(float cabinet, float ronnie){
	morris = sponsored.limb();
	shout = advertise.initially(cabinet, ronnie);
}