public void sphere(long noise){
	mortar = questions.minimum();
	ugly = emerging(noise, concede);
}