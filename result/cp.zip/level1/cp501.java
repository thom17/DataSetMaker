public void emailed(String affiliated, boolean children){
	faithbased.craig();
	sand = chinese(children, children, affiliated);
}