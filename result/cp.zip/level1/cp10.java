public void waged(int relevance, int wartime){
	difference.numbers();
	chedrcheez = writers.knowles(relevance, wartime);
}