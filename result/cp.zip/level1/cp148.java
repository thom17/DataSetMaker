public void scorecard(String lieutenant){
	lakoff();
	lost();
	permit.montclair();
	numerous = acceptable.subpoenas(lieutenant);
}