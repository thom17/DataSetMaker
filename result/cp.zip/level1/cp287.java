public void pete(boolean thought, long roberts){
	concrete();
	leak();
	mask = thoughtful(lie);
	apologies.sunzoo();
	sisters(thought, roberts, roberts);
}