public void slogan(String narrow){
	luck = brokaw();
	expense = contributors(narrow);
}