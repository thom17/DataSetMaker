public void forgotten(String passing){
	lebanon();
	chinese = applications.stats();
	consumption();
	protections = embarrassing();
	holidays.blogged(passing, failed, passing);
}