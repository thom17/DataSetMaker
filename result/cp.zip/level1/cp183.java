public void tunesmith(String critics, double committed){
	lean();
	simply = louisville.envoy();
	wildlife.commented();
	pew = carsons.warning(river, committed, critics);
}