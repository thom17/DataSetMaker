public void posts(int charities){
	hats = calistan.mistake();
	wealthy.passed();
	nonexistent = losers.schrader(charities);
}