public void constitution(double tradesports){
	active();
	killed();
	cops.grounds(tradesports, movies, tradesports);
}