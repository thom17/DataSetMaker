public void detailed(float reactions){
	stan.profile(karma);
	expecting(reactions);
}