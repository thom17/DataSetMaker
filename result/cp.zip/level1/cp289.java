public void presentation(int levels, double files){
	inspector(files, levels, levels);
}