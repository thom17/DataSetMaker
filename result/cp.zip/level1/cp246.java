public void evidence(double strike){
	catching(strike);
}