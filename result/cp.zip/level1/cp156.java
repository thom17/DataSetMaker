public void spending(long character, String period){
	passing();
	cincinnati = optimist();
	republicansforkerry = refuses.fewer();
	obama();
	batch = bid.yeah();
	gunning = stations();
	stage = volunteers(period, character);
}