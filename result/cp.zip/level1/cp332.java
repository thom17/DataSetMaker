public void regime(String compelled, float continuing){
	dfa = flame(continuing);
	territory(continuing, continuing);
	initiatives();
	errors = kossacks();
	legislature(compelled, compelled);
}