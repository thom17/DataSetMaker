public void asses(boolean austin, String supposedly){
	announce.prince();
	felt = insist.arg();
	wall.broadcasting(austin, supposedly, revenue);
}