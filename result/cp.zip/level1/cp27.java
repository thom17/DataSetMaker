public void forms(long mtp){
	seconds = appalling.opposite();
	favors();
	appointed(mtp, prewar, mtp);
}