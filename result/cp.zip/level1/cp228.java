public void missouri(long houses, float pissed){
	troubles.republican();
	society.hundreds(pissed, houses);
}