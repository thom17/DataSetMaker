public void ndp(int protections, boolean prokerry){
	safer.janklow();
	seats();
	find = jay.towns(prokerry);
	boring = investigating();
	embarrassing.civilized();
	opponent = pictures();
	view.supervisor(prokerry, protections, educated);
}