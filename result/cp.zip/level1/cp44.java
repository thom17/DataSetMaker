public void patriots(String defend, float allimportant){
	showing();
	scathing.andrew(allowing, allimportant);
	western.quinnipiac();
	phones(defend);
}