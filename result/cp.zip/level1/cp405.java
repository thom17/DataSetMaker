public void stubborn(String presided){
	philadelphia = attached.donnelly();
	contributions();
	august.pol();
	trippis = shakeup();
	rates();
	organizers = windows();
	gays.committed(presided, presided, lieutenant);
}