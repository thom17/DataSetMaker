public void stan(boolean israeli){
	vice.tancredo(israeli, worker, israeli);
}