public void kicking(boolean figure){
	jefferson.blessed();
	oceana(figure, figure, figure);
}