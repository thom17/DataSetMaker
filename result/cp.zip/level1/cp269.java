public void sending(double nagging){
	materials.stretch(nagging, nagging, nagging);
}