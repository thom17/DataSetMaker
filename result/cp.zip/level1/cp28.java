public void contributing(float dead){
	profiles = angst();
	understanding(dead, dead);
}