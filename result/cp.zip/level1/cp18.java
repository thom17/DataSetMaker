public void suggestion(float taxes, long expenditures){
	firing = involved();
	ends = precinct.trix(taxes);
	underestimate();
	archives = absence(expenditures);
}