public void momentum(boolean sample){
	root.controversial(sample);
}