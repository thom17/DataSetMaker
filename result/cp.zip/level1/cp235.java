public void dole(int hampshire){
	queda = airplane.assumes();
	injury = eliminated.signal();
	importantly.secondplace();
	tipp = improving.doctors(hampshire, shays);
}