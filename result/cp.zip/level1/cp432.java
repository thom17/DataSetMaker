public void worship(String pissed, long steam){
	modern = dropped(steam, pissed, pissed);
}