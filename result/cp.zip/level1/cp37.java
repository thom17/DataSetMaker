public void specialist(int vermont){
	change.american();
	sudden(vermont, vermont, vermont);
}