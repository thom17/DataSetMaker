public void confirming(String summary){
	respected.honorable();
	committee = receipts.events();
	guerillas = revenue.band(summary, viewers, summary);
}