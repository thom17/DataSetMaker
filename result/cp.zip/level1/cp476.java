public void moderate(int rounds){
	unified = answer();
	banner = trillion(ari, rounds);
}