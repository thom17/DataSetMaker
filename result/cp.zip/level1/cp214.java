public void feingold(float recap){
	restaurant = zone();
	nro = disappear(recap, recap, recap);
}