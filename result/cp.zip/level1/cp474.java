public void partly(double floating){
	experienced = continuing.caucusgoers();
	boards.seemann();
	asserted = planners(floating, floating, floating);
}