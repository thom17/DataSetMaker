public void electronic(double tied, double persistent){
	senor.higher();
	arena = props.socalled();
	weber.slipped();
	counter.mcentee();
	forecast.hiding(tied, caps, persistent);
}