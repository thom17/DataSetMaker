public void permanently(int element){
	upbeat.decisions();
	exceed();
	booth();
	windows = failing.debates();
	promotion = sole.access();
	essence.play(element);
}