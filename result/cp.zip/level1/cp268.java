public void moqtada(long refuses){
	dog = communion();
	aspect();
	positioning(refuses, refuses);
}