public void bean(int lay){
	ten = april.ports();
	worthless(lay, quote, lay);
}