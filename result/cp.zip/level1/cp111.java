public void advertise(boolean rewards){
	hed.contested(tunesmith, rewards);
}