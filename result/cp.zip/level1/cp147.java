public void bounds(long walmart){
	ties = miracle(walmart, walmart, walmart);
}