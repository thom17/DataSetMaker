public void falling(long confederate, String onetime){
	judgment.declaring(onetime, confederate);
}