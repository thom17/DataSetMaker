public void arrogant(float worthless, long dissent){
	unlimited = dscc(dissent, dissent, dissent);
	book = experiment(dissent, dissent, worthless);
}