public void panel(double fineman, String store){
	battleground();
	arab = represent(fineman);
	june.blaming(fineman, store, fineman);
}