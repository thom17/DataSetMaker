public void succeed(boolean rncs, String jim){
	contractors = suicide.reasonable();
	conventional = gave.reflected(jim, rncs, rncs);
}