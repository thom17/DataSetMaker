public void watching(String decide){
	contradicted();
	peoples.threshold(dodge);
	tracking.oil();
	fought = attitudes();
	wasnt = transfers(decide);
}