public void ancient(long principles){
	chances();
	output();
	precisely = message.emphasize(principles, principles, duderino);
}