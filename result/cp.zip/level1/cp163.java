public void beach(double nickles){
	sailor = reject();
	withdrawing(nickles, reviewing, nickles);
}