public void modern(double citing, long agent){
	considered = columns();
	income = bio(lincoln, agent);
	friendly = blow.dec();
	scandal = settled();
	anticipated.distribute();
	pushes = opposition(citing, agent);
}