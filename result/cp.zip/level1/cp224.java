public void administrator(float hmm, float burn){
	fridays = temporary(burn);
	explain(burn, hmm);
}