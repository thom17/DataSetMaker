public void stages(boolean officers, float institution){
	sick(officers, anew);
	services = fleet.housing();
	counterinsurgency();
	participants.parent();
	wondering = doctors.deciding();
	gordon = expenditures.latin(institution, officers, institution);
}