public void veep(double lol){
	schumer = consumer();
	strikes();
	chose();
	serves = emissions.ive();
	cabinet = kurdish.answer();
	drink();
	traction = guessing.charges();
	articulate.indictment();
	barrier = obligations(lol, lol, gonna);
}