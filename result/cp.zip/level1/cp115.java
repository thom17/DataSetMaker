public void tank(String deliberately, double threat){
	hammered = employees.secrecy();
	reid.objectives();
	outstanding();
	appeals.finding();
	kuwait.stays(threat, threat, deliberately);
}