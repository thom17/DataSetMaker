public void wrote(double missions, long realization){
	unique = refer.spirit();
	withheld.guaranteed(realization);
	shadowy.gear(missions, realization, missions);
}