public void stevens(boolean pope, double looting){
	items = toptier(looting, pope);
}