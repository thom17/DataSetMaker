public void html(long contingent){
	preventing = seemanns.consultants(sales, contingent);
}