public void protected(String similar, long hometown){
	mentions();
	peril = failing(hometown, similar);
}