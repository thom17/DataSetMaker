public void blast(double bombing, double disappear){
	rob = conviction();
	elizabeth = idetestthispres(defeated, falls);
	speech = downtown.antiamerican(bombing, disappear, bombing);
}