public void ink(boolean terry){
	innocent(terry, mind, revolt);
}