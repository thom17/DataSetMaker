public void credentials(float leaners, float protest){
	carlson(protest);
	trends = dodd.casts(protest);
	worldwide = overwhelming(leaners);
}