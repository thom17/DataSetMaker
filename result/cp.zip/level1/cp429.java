public void explicitly(float hates){
	adams = lott.guests();
	announcing.initiatives(hates, hates);
}