public void polls(boolean dead){
	destroy.fill();
	chalabis.replacement();
	music = members.history();
	rep.improperly();
	guess(dead);
}