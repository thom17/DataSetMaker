public void huge(boolean hated){
	express(hated, hated);
}