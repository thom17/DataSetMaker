public void ranks(double percentages, int located){
	dramatically = judith();
	device = ado();
	brit = privately.airing();
	gadflyer = newberry(located, percentages);
}