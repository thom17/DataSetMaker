public void eric(long solid, long civilians){
	entire.traditionally(solid, solid);
	capable(civilians, civilians);
}