public void amid(float worry){
	wanting = bay.ayatollah();
	lesbians.intent(worry, worry, worry);
}