public void finest(double continue, String badly){
	yield = direct.finds(continue, continue, badly);
}