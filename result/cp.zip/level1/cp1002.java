public void source(long truman, double hostility){
	chambers(hostility, truman);
}