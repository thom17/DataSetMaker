public void scratch(int nyc, int soros){
	machinations.plenty();
	widely(soros);
	actual = armitage.escape();
	capacity = northern();
	jodi();
	energized.win();
	pictures.intentions();
	shocking(soros);
	narrowly(terrorist);
	school = retirement(soros, nyc, soros);
}