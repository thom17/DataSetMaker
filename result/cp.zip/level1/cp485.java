public void costs(String facts){
	display = jury.matchup();
	liberties(facts);
}