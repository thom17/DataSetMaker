public void birthday(boolean anthony){
	accomplishment();
	chuck.blogpac();
	performance.horrific(anthony, yeah, anthony);
}