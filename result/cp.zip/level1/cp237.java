public void lvs(double francisco, boolean canadian){
	exercise(francisco);
	shia.categories(suggested);
	aims.key();
	liberalrakkasan(canadian, francisco, francisco);
}