public void arg(long provided){
	kentucky();
	guide = naders();
	intend = family(provided, provided);
}