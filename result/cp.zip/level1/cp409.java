public void directed(int labor, double deals){
	ann = billions(labor, deals, deals);
}