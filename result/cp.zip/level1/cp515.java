public void article(double hip){
	threatens.puppet();
	pin = arizona.midnight();
	outrage = pride();
	quotes = hollywood();
	soil = thought.rationales();
	broadcasting = ive();
	chronicle = bodies.goals();
	learning = sanctions.delegation(hip);
}