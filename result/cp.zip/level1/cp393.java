public void lynne(boolean constituency){
	regain = payroll(constituency, constituency, debt);
}