public void traditions(double guidelines){
	pragmatic.heroism(installed, guidelines);
}