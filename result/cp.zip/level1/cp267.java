public void deliver(String lieberman){
	task.fanatics();
	intention(yahoo, lieberman, lieberman);
}