public void notably(double presidents){
	immigration();
	resident = knocked.achieved();
	chest = observation(presidents, presidents, presidents);
}