public void hecht(double excerpts, long incidentally){
	shot.demands(excerpts);
	understands = supplemental.discourse(incidentally);
}