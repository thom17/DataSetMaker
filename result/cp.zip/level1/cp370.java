public void backers(float shook, double traffic){
	stay.important();
	mortar();
	breathtaking();
	stealing = wildlife(smears, traffic, planes);
	reading = petraeus.excellent();
	painful(shook, shook, traffic);
}