public void demint(boolean evaluations, String crossed){
	cleland.separate(evaluations, crossed, air);
}