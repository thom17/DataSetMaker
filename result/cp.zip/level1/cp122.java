public void perform(float census, long disregard){
	ribbons = universe(disregard);
	jack.ineffective(fla, disregard);
	bug.cultural();
	millers.dispatch();
	confirmation = alaska.devoted(census);
}