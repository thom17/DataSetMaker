public void offers(double bits){
	exchange(bits);
}