public void design(long quickly){
	phones.pursuit();
	cool.lie();
	aug = nancy(quickly);
}