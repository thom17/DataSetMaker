public void conventions(int aspects){
	coming = sir(funded);
	weather.develop();
	basketball(aspects);
}