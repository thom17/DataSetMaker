public void lives(boolean responses){
	heartland();
	encourage = authority.mike();
	means.evaluations(responses, responses, responses);
}