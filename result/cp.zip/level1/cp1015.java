public void green(String relied, String damage){
	jones = warning();
	flops = saddam(damage);
	arnold = households();
	schaffer.brock();
	disputed.cautious();
	slip = declared.britain();
	colorados();
	niche = average(circle, damned, speeches);
	controlled = nra(damage, relied, relied);
}