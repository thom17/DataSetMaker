public void fallen(double unconstitutional, boolean sway){
	minnesota = boat();
	oversight(moving, unconstitutional, sway);
}