public void principal(double brock, boolean chances){
	contributed(brock);
	downing(chances, chances, brock);
}