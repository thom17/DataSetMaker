public void followup(float career){
	irans = secular();
	unique = equivalent.executive(career, career);
}