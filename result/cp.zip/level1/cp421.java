public void propose(double apply){
	participants = traditional.girls();
	ice = durbin();
	locals.gooper(apply);
}