public void walter(int demand){
	reached.inactive(demand, demand);
}