public void latino(String commonwealth){
	examine();
	guys();
	unsuccessful(commonwealth);
}