public void oath(double force, double acted){
	extensive.spokeswoman();
	schneider = mirror();
	atrocities.kenny(acted, resistance, force);
}