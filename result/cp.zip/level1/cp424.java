public void powered(boolean seamus){
	echoed.illusion(seamus, seamus);
}