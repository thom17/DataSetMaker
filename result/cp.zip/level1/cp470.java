public void cargo(double tenenbaum, String legs){
	carried = legislation();
	coal.herald();
	hubris = ending();
	succeeded = tear();
	pretend = roughly();
	excuse = mcgovern.conspiracy(tenenbaum, legs, tenenbaum);
}