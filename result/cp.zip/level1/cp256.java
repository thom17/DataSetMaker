public void ongoing(float caught, boolean soviet){
	projects.themes(caught);
	dash(soviet, soviet, caught);
}