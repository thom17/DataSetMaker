public void hostage(double medicine, String easily){
	colleague(easily);
	marriage = unexpectedly.drafted(easily, ranging, easily);
	depend(easily, medicine, medicine);
}