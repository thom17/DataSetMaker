public void battlefield(String craft, int commercial){
	addressing = broadcasting.credit(commercial, ludicrous);
	allen.foes(craft);
}