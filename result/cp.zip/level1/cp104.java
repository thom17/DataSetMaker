public void publicly(long stan){
	iraqs.dhinmi();
	deeper(stan, restaurant, stan);
}