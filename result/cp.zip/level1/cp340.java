public void solutions(double locations){
	plans = mehlman();
	talked.pennsylvania(locations);
}