public void defeated(String atrios){
	preemptive(atrios);
}