public void happen(int filing, int japanese){
	time(filing, filing);
	george = scene();
	apt();
	minimize.limbaugh();
	poses = promotion(running);
	challenged = numbers.ohios(enjoyed, filing);
	trading.scalia(japanese, japanese, filing);
}