public void congrats(int alqaida, int collecting){
	boston.dance();
	distributed.sucking();
	introduce();
	oconnor.stoller();
	wow(alqaida, alqaida);
	difficulty();
	jimmy.overview();
	pataki = storks.feb(alqaida, collecting, collecting);
}