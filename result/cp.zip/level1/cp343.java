public void emailed(double survive, int effort){
	echoed = chatter.sanity();
	lugar(survive, effort);
}