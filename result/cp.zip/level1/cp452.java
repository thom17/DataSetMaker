public void chambers(String spectacular){
	congrats.stages(spectacular, gasoline, rumor);
}