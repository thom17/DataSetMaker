public void announce(long wont, double anymore){
	photos();
	reporter.hiring();
	pushed.commented();
	mike.grim();
	deans.rose();
	rank(wont, anymore, wont);
}