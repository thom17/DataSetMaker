public void affiliates(double magazine, long relying){
	lives = spectacular.son();
	minds = category();
	emails = rad.tanks(magazine, relying);
}