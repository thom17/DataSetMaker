public void philadelphia(double originally, int scores){
	recommendation = implied();
	tight = death.crass(wont, scores, scores);
	providing(originally, campbell);
}