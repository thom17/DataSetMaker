public void sucking(double dismissed){
	opponents = publicity(dismissed);
}