public void clout(boolean dynamic, boolean abroad){
	institutions(dynamic, dynamic, dynamic);
	blogads = chuck();
	forcing();
	context(abroad, abroad);
}