public void ports(String frists, double interview){
	robert(interview, frists);
}