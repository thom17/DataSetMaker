public void signature(int consumer){
	missiles = separate.operatives(consumer, consumer);
}