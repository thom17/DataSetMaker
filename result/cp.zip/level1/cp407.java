public void fundraiser(int guest, float heaven){
	hundreds = idetestthispres();
	charles = police();
	promise(heaven, heaven, guest);
}