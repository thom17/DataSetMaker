public void attractive(boolean grave, float execution){
	burns.life();
	defeat();
	feared = cutter.radar();
	wheels = investigations();
	nod.aarp(execution, execution, pundit);
	whos(grave);
}