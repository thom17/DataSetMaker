public void presentation(long wmd){
	fails = enjoys.payroll(wmd);
}