public void matthews(String fiercely){
	glory = moores.mercenary();
	tensions = family(perfect, fiercely, fiercely);
}