public void location(String betting){
	map.sunday(turns, improbable);
	narrowed.patients(betting, betting, betting);
}