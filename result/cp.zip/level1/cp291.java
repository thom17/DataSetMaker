public void spokeswoman(boolean tank, String unemployment){
	walking = feingold();
	returned = nonexistent.amphibians(unemployment, tank);
}