public void readers(String skews){
	armys();
	andrew = conti.voter(supporter);
	gores(skews, skews);
}