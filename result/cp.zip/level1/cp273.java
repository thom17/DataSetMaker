public void fears(long thune){
	detention();
	children(entitled, thune, thune);
}