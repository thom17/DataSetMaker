public void pushed(float notorious){
	facilities = solutions.asian(notorious, notorious, notorious);
}