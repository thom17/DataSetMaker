public void justified(boolean brahimi){
	marine(ben, brahimi, brahimi);
}