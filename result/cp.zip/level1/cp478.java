public void values(double ending, int contained){
	themes();
	assuming();
	elite = sons.coulter(contained);
	thirdplace = advantages();
	consequences = protesters(contained, contained, ending);
}