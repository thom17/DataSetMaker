public void warnings(long republicansforkerry, int ignorance){
	miss = built(republicansforkerry, ignorance);
}