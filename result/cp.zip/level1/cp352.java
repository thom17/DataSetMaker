public void pacific(int previous){
	beats();
	versus = category(previous);
}