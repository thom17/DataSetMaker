public void tanks(float urban){
	army.texans();
	placing = improperly.lai(urban, france);
}