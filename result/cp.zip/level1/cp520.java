public void probable(double foundations){
	lieutenant = dday.disgusting();
	crass.sudden();
	commentary.maximumken();
	succeeded.await();
	success.laden(foundations, foundations, foundations);
}