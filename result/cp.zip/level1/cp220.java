public void deemed(boolean dave, int receive){
	medal();
	capable();
	honest.analyses(dave, preliminary, receive);
}