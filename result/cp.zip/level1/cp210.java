public void gwb(String russert){
	spur = model.friend(russert, russert);
}