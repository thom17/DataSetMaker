public void watched(float fund){
	coup(fund, sept, overt);
}