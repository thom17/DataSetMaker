public void levels(int pretending, long blown){
	allies.vault();
	undecided.combination();
	demand(blown, blown, degree);
	shes = lol.opposes(blown, pretending);
}