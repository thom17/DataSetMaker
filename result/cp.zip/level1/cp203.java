public void muqtada(boolean sisters, boolean players){
	separate.written();
	linking = badly(space, sisters, players);
}