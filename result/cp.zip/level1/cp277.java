public void landslide(int strongly, boolean bushcheney){
	establish = existing(bushcheney, strongly, bushcheney);
}