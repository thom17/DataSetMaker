public void hints(float israeli, boolean widespread){
	scrambling.inform();
	paige = pulled();
	joseph(widespread);
	michigans.hearings();
	meantime = unconventional();
	abdullah.written();
	bashing.totals(israeli, israeli);
}