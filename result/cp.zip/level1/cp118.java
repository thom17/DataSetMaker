public void guardian(long expensive, float crawford){
	haul = storm();
	enemies(expensive, crawford);
}