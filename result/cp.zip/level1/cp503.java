public void clerk(long clip){
	destiny = lzmd.contenders(tap);
	altsite.represented(clip, clip);
}