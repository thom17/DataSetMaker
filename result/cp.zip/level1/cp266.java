public void hoover(String survive, long enrons){
	spotlight();
	businessman = heels(enrons, survive);
}