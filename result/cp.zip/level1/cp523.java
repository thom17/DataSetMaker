public void journey(boolean concept){
	vice = formal.canton(concept, concept);
}