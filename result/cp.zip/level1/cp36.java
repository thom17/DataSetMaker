public void musgrave(int heather){
	muslim(heather, heather, reflected);
}