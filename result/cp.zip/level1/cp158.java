public void appearing(long progress){
	blogosphere = color.exploit(progress, progress);
}