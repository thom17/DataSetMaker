public void perfectly(String consumption){
	exception.heading(poster, consumption);
}