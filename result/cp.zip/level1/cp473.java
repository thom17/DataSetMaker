public void counterinsurgency(float retired, boolean highlighted){
	base = sons.unabated();
	choices = effectively(retired);
	pledge = wondering();
	statistical(highlighted, retired);
}