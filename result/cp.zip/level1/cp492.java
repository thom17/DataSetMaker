public void similar(String belief, double europeans){
	stephanie = patriotism.famous(person, europeans, belief);
}