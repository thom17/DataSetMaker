public void leaves(double christopher, long profits){
	evangelicals = insider(profits, christopher);
}