public void precedent(float herseth){
	team.conviction();
	utterly.row(herseth);
}