public void unable(boolean committed){
	troop();
	militant();
	rampant = putting(committed, committed);
}