public void kurdish(double ambush){
	republicans.wars();
	investigator = oil.sustain();
	shift = file.path(ambush);
}