public void formed(long deficits, long bug){
	direwolf.jackson();
	manage.upper();
	jerome(deficits, bug);
}