public void attempts(String advocates){
	nato = consideration.duration();
	switch = guards(advocates, advocates);
}