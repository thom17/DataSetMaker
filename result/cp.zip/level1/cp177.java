public void cent(long afternoon, double contact){
	fort = attempts.alive(contact, contact, soil);
	prefer = body.israel(contact, afternoon, contact);
}