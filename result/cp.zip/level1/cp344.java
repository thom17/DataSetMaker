public void duty(float losing, float discovered){
	publicity();
	advertise = media.journals();
	liebeck();
	mad = prepared.types(boxrdf_feeds);
	cards = minor.beautiful();
	senator.disgusting(losing);
	litigation = montclair();
	figure(losing, persuade, discovered);
}