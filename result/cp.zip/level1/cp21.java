public void sand(int entry, boolean delivering){
	pelosi(entry);
	gore = desperate.findings();
	embarrassing = admission.featuring();
	tensions = challengers.ensure();
	employment(entry, delivering);
}