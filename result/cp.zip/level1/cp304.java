public void younger(boolean forgot, boolean resistance){
	milestone.realistic();
	baghdad = nice.militia(forgot, forgot, resistance);
}