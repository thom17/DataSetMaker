public void jodi(long congressional){
	justices = cuts();
	burt = mike(congressional, congressional);
}