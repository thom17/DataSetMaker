public void undermined(boolean clever){
	regimes();
	lobbying.pollution();
	powerful = rise(clever, clever, clever);
}