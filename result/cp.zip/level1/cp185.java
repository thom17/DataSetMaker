public void eye(double surprised, String nazi){
	disgraced.honor();
	selling = insane.camp(purely, manchester);
	fed = coming(friday);
	scared();
	dukakis = heartland.inching(surprised, nazi);
}