public void calculate(int controlled){
	critic = minimize();
	houston.stupid();
	tapes = twothirds(controlled);
}