public void dod(int involved){
	watching();
	eliminating(involved);
}