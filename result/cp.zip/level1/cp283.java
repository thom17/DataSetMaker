public void prices(float posed){
	secret();
	winnable = assistant(posed, posed, posed);
}