public void motives(String konop){
	luaptifer();
	competent.innocent(purpose, konop, konop);
}