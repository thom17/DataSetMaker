public void successful(long basis){
	timid = complaint();
	woodward = profits();
	amendment = french.exploration();
	moveonorg.compelling(basis, basis);
}