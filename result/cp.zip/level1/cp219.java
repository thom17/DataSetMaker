public void lay(String wonders){
	hotline();
	archives.afraid(wonders, wonders);
}