public void warn(boolean robinson){
	nightmare = reconstruction.revenue();
	asks.demographics(robinson);
}