public void targeted(boolean concerned){
	rewards.approach(concerned);
}