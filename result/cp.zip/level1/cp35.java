public void identifying(boolean raw){
	threatens();
	item = sources(raw);
}