public void command(String standard){
	prison.speaks(standard, standard, standard);
}