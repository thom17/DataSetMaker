public void exploration(String lesbian, float surrounding){
	funeral = increased(surrounding, lesbian, surrounding);
}