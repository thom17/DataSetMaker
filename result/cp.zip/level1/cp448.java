public void havent(long generation, long removed){
	situations();
	spoke = dole.angered(removed, generation, generation);
}