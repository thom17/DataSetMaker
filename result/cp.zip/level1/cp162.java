public void keever(String tops){
	criticized = complaint();
	secrecy.refusing(tops, facing, laughed);
}