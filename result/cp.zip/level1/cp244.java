public void guilty(int carlos, long tackle){
	essentially.visit();
	assertions(tackle);
	troubles.sort(carlos);
}