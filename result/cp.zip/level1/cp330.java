public void internal(String collective){
	guantanamo();
	letting();
	dollar = strategist.opponent();
	suggestion.racist(collective, collective);
}