public void possibility(long html){
	suffered = calculate.wingers();
	electoral.matches();
	research = powered();
	flash = boss(html);
}