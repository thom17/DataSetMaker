public void strong(int greens){
	damned.scare(greens);
}