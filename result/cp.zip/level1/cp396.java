public void careful(boolean domestic){
	drilling(domestic);
}