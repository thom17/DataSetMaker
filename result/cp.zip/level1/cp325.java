public void commercial(double season, float katerina){
	rap.historic(ridiculous, season, katerina);
}