public void responsive(float specifically, String plenty){
	conceded.modest();
	urban(plenty, plenty);
	worse = planning();
	litigation = hardball(specifically);
}