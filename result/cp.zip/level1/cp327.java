public void issuing(double replacing, boolean ripped){
	fond = cho(card, replacing);
	clark(clip, ripped, answered);
}