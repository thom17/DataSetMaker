public void wyoming(long enters, int gradually){
	neutral = keever.proven();
	ramadan(gradually, enters);
}