public void masters(double asia){
	reelected(dough, asia, asia);
}