public void spend(float helped, float gift){
	weekend(gift, helped);
}