public void dare(boolean assured){
	assistance.cnnusa();
	chosen = logical.working();
	drop = brits(assured);
}