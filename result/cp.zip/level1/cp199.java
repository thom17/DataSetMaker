public void occurred(boolean spoken){
	arrests = group();
	terror.podium();
	diversity = searches.shifts(spoken);
}