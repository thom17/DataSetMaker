public void washingtons(String consequences){
	veep = password(consequences, consequences, overview);
}