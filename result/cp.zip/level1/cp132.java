public void drinking(String dearborn){
	disclose();
	specialist = stirling.offers();
	tipp = attack.title();
	quiet.delaware();
	advised = wasted.photo();
	puppet = urging.average();
	citizens = maine();
	helpful = cowardly.hostage();
	industrial.unions();
	aint = developments.freshman();
	reynolds = cards.started(dearborn, dearborn);
}