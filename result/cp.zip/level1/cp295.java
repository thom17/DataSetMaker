public void identify(float mustve, String limbaugh){
	bona.hack();
	inquiry = announcing(mustve);
	northup = accusations(limbaugh);
}