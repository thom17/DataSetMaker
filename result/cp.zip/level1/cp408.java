public void william(long selling){
	crying.opposite(selling, selling);
}