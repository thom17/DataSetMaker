public void require(String trapper, boolean splice){
	ass = probable.perle();
	indication = mortar.activism(splice, splice);
	whine = staying.salient();
	violence.tom();
	cooperation = ethic.longtime(splice, trapper);
}