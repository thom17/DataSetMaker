public void tuned(String usual, long healthcare){
	elected = intel();
	safer = missiles();
	images = honor();
	supplies.ceiling();
	alexander = server(immigration);
	abcs.personality(usual, usual);
	evangelical = defending.headtohead(usual, healthcare);
}