public void bowles(float luck){
	protesters = dave(luck);
}