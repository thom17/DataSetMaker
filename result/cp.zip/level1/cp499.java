public void katherine(String loaded){
	fallout.ignorance(loaded, loaded);
}