public void forcing(long stagflation){
	infamous = rcalif.council(stagflation);
}