public void suspect(long titled){
	pure.evans();
	pete = campbell();
	russert = sanchez(explosion, invented, titled);
}