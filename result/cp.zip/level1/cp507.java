public void approaching(String quote){
	rendell.troop();
	undercut();
	ended = offer();
	speaks = chance.testimony();
	audio();
	minimum.manchester(quote);
}