public void ideals(boolean food, int seemingly){
	listeners.october();
	released(seemingly, food);
}