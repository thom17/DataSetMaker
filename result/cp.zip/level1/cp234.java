public void vacation(float message){
	pledged.precious(message);
}