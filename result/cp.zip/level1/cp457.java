public void upward(long bear, long gross){
	reviewing.sector();
	showed(bear, gross, inspection);
}