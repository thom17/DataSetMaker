public void loyalists(long prime, boolean forget){
	stayed = mansion.brand();
	investigation = predictive.raw();
	dayton = copy.enemies();
	broder = historic.lobbying();
	page(prime);
	account = contempt.leave(forget, prime);
}