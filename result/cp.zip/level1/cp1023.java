public void forces(float throwing){
	commanding = reviewing();
	konop();
	cheneys = resigned.blank();
	moseley = accidents.institute(fighter, dec);
	stump(throwing, throwing);
}