public void archpundit(float wartime){
	girl(wartime, claire);
}