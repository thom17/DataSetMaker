public void dole(float equality, long flying){
	contributions.danger(flying);
	sisters = steps.iii();
	protesters = clarks.cole(equality, flying);
}