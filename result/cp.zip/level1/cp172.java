public void historically(float divided){
	hours(divided, divided);
}