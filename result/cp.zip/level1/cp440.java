public void tough(double wounded){
	libertarians.featuring();
	excerpts(wounded, develop);
}