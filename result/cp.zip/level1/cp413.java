public void cleveland(int disastrous, String english){
	baathist();
	housing.rare();
	discipline();
	time = skills.dakota(disastrous, disastrous, english);
}