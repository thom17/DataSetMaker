public void collar(long flop, String capacity){
	fence.fond(capacity, capacity, presided);
	postconvention = glenn.defeat(pressure, flop);
}