public void directors(boolean moqtada, int realitybased){
	freedoms = gharib.sunni();
	regarded = routine();
	quest = allowed();
	stationed();
	amidst();
	employees.lived(moqtada);
	outraised.tennessee();
	playing(households, realitybased);
}