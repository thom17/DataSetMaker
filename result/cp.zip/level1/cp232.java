public void expenditures(int barbero){
	litmus.campbell();
	song.technical();
	losers = promoting();
	bastion = crew.lays();
	bode.mental();
	analyses = added();
	officials.partisan();
	handing = internet();
	halt(barbero, barbero);
}