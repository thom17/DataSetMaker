public void armitage(String extra, float poor){
	deceits = eerily();
	jul = upward.filter(extra, poor);
}