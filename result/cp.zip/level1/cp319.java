public void warfare(int briefly){
	retirement.rob();
	revelations.rules();
	minimize = pulling.counterparts(briefly);
}