public void structure(double song){
	beliefs = reverse(calculator, song);
}