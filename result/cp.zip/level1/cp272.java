public void hole(double radicals){
	explosion = phrase.negotiating();
	creates = ohpres.states();
	woodward = firms(radicals);
}