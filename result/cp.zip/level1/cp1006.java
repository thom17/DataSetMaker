public void katerina(boolean investigated, int mate){
	residents = china.branch();
	arab = cheer.issues(investigated);
	humans = teachers.major();
	appeared = payments.insurance();
	establish();
	sierra = blog(pool, mate, investigated);
}