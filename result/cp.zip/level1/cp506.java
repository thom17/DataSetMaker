public void economic(String pat, int interviewed){
	blogosphere.role();
	betting.ethics();
	wsj(pat, interviewed);
}