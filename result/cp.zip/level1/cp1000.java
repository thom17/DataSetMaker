public void cool(int jfk){
	program.development(jfk);
}