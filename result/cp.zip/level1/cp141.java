public void agree(int granted, double equation){
	mongiardo.persian();
	wapo = sweat();
	slowly(equation);
	donald = treat.netroots(granted, granted);
}